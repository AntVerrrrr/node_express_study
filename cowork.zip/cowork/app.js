const express = require('express');

const app = express();

let members = require('./members');

app.use(express.json());    //서버로온 req바디의 json데이터가 존재할 경울 그것을 추출해서 req의 바디에 넣어준다.

app.get('/api/members', (req, res) => {
    // res.send(members);
    const {team} = req.query;
    if (team) {
        const teamMembers = members.filter((m) => m.team === team);
        res.send(teamMembers);
    } else {
        res.send(members);
    }
});

app.get('/api/members/:id', (req, res) => { 
    const {id} = req.params;
    const member = members.find((m) => m.id === Number(id)); //이해 됨

    if(member) {
        res.send(member);
    } else {
        res.status(404).send({message: 'there is sno such member'});
    }
});


// 새 직원 정보 추가하기
app.post('/api/members', (req, res) => {
    const newMember = req.body;
    members.push(newMember);
    res.send(newMember);
});

// 기존 직원 정보 수정하기
app.put('/api/members/:id', (req, res) => {
    const {id} = req.params;
    const NewInfo = req.body;
    const member = members.find((m) => m.id === Number(id));
    if (member) {
        Object.keys(NewInfo).forEach((prop) => {
            member[prop] = NewInfo[prop];
        });
        res.send(member);
    } else {
        res.status(404).send({ message: 'there is no member with the id!'});
    }
});

// 직원 정보 삭제하기
app.delete('/api/members/:id', (req, res) => {
    const { id } = req.params;
    const memberCount = members.length;
    members = members.filter((member) => member.id !== Number(id));
    if (members.length < membersCount) {
        res.send({ message: 'Deleted'});
    } else {
        res.status(400).send({message:  "there is no member with the id!"});
    }
    
});

app.listen(3000, () => {
    console.log('server is listening...')
});